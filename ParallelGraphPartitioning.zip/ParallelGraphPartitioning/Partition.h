#pragma once
class Partition
{
public:
	Partition();
	~Partition();
};

