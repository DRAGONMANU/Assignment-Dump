#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string>
#include <string.h>
#include <stdlib.h>
#include <vector>
#include <algorithm>
#include <mpi.h>
#include "omp.h"

using namespace std;

typedef struct MyTuple
{
	int r;
	int c;
	int k1;
	float k2;
}MyTuple ;

void printTuple(MyTuple t)
{
	cout<<t.r<<" "<<t.c<<" "<<t.k1<<" "<<t.k2<<"\n";
}

vector<MyTuple> input;

bool row_major(const MyTuple & a,const MyTuple& b)
{

   	if(a.r < b.r)
   		return true;
   	else if(a.r==b.r)
   		return a.c < b.c;
   	else
   		return false;

}

bool col_major(const MyTuple & a,const MyTuple& b)
{
   if(a.c < b.c)
   		return true;
   	else if(a.c==b.c)
   		return a.r < b.r;
   	else
   		return false;
}

bool sort_float(const MyTuple & a,const MyTuple& b)
{
   if(a.k2 < b.k2)
   		return true;
   	else if(a.k2==b.k2)
   		return a.c < b.c;
   	else
   		return false;
}

bool sort_int(const MyTuple & a,const MyTuple& b)
{
   if(a.k1 < b.k1)
   		return true;
   	else if(a.k1==b.k1)
   		return a.r < b.r;
   	else
   		return false;
}

void readInput(const char* inputfile)
{
	ifstream inputFile(inputfile, ios::in | ios::binary);
	if (!inputFile)
	{
		cout << "can't open file" << endl;
		exit(1);
	}
	int r,c,k1;
	float k2;
	while(inputFile.read(reinterpret_cast<char *>(&r), sizeof(int)))
   	{
   		inputFile.read(reinterpret_cast<char *>(&c), sizeof(int));
		inputFile.read(reinterpret_cast<char *>(&k1), sizeof(int));   		
		inputFile.read(reinterpret_cast<char *>(&k2), sizeof(float));
		MyTuple t;
		t.r = r;
		t.c = c;
   		t.k1 = k1;
   		t.k2 = k2;
   		input.push_back(t);
   	}
   	inputFile.close();
}

void printfile(const char* outputfile)
{
	ofstream outputFile (outputfile, ios::out | ios::binary);
	if (!outputFile)
	{
		cout << "can't open file" << endl;
		exit(1);
	}
	// TODO
	for (int i = 0; i < input.size(); ++i)
	{
		int r = input[i].r;
		int c = input[i].c;
		int k1 = input[i].k1;
		float k2 = input[i].k2;
		outputFile.write(reinterpret_cast<char *>(&r), sizeof(int));
		outputFile.write(reinterpret_cast<char *>(&c), sizeof(int));
		outputFile.write(reinterpret_cast<char *>(&k1), sizeof(int));
		outputFile.write(reinterpret_cast<char *>(&k2), sizeof(float));		
	}
	outputFile.flush();
	outputFile.close();
}

void SendData(vector<MyTuple>* shoot,int dest)
{
	MPI_Send((void*)shoot->data(),shoot->size() * sizeof(MyTuple), MPI_BYTE, dest, 0, MPI_COMM_WORLD);
}

void RecvData(vector<MyTuple>* shoot,int dest)
{
	MPI_Status status;
	int incoming_size;
	MPI_Probe(dest, 0, MPI_COMM_WORLD, &status);
  	MPI_Get_count(&status, MPI_BYTE, &incoming_size);
  	shoot->resize(incoming_size / sizeof(MyTuple));
	// MPI_Recv((void*)shoot->data(),incoming_size, MPI_BYTE, dest, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
}

void sortColsInRow(int maxrows)
{
	int j = 0;
	int jt = 0;
	for (int i = 0; i < maxrows; ++i)
	{
		// cout<<"i = "<<i<<endl;
		vector<MyTuple> t;
		jt = j;
		while(input[j].r==i)
		{
			t.push_back(input[j]);
			// printTuple(input[j])
			j++;
		}
		// cout<<"jt = "<<jt<<" j = "<<j<<endl;
		if (t.size()>0)
		{
			sort(t.begin(), t.end(), sort_float);
		}

		int k = 0;
		while(jt<j)
		{
			input[jt].k1 = t[k].k1;
			input[jt].k2 = t[k].k2;
			jt++;
			k++;
		}
		t.clear();
	}
}

void sortRowsInCol(int maxcols)
{
	int j = 0;
	int jt = 0;
	for (int i = 0; i < maxcols; ++i)
	{
		// cout<<"i = "<<i<<endl;
		vector<MyTuple> t;
		jt = j;
		while(input[j].c==i)
		{
			t.push_back(input[j]);
			// printTuple(input[j])
			j++;
		}
		// cout<<"jt = "<<jt<<" j = "<<j<<endl;
		if (t.size()>0)
		{
			sort(t.begin(), t.end(), sort_int);
		}

		int k = 0;
		while(jt<j)
		{
			input[jt].k1 = t[k].k1;
			input[jt].k2 = t[k].k2;
			jt++;
			k++;
		}
		t.clear();
	}
}

int main(int argc, char const *argv[])
{
	if (argc!=5)
	{
		printf("wrong arguements\n");
		exit(1);
	}
	MPI_Init(NULL, NULL);
	int world_rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
	int world_size;
	MPI_Comm_size(MPI_COMM_WORLD, &world_size);

	int maxrows = atoi(argv[3]);
	int maxcols = atoi(argv[4]);
	int debug = 1;
	if (world_rank == 0)
	{
		readInput(argv[1]);
		// if (debug==1)
		// {
		// 	for (int i = 0; i < input.size(); ++i)
		// 	{
		// 		printTuple(input[i]);
		// 		cout<<"AS"<<i<<" ";
		// 	}
		// }

		for (int i = 0; i < 4; ++i)
		{
			sort(input.begin(), input.end(), row_major);
			sortColsInRow(maxrows);
			sort(input.begin(), input.end(), col_major);
			sortRowsInCol(maxcols);
		}		
	}

	// // Sort according to col
	// if(world_rank == 0)
	// {
	// 	// Send data acc to chunks to each proc
	// 	for (int i = 1; i < world_size; ++i)
	// 	{
	// 		for (int j = 0; j < chunkSize; ++j)
	// 		{
	// 			if((i-1)*chunkSize+j >= cols)
	// 				break;
	// 			SendData(&input[(i-1)*chunkSize+j],i);
	// 		}
	// 	}
	// }
	// else
	// {
	// 	for (int i = 0; i < chunkSize; ++i)
	// 	{
	// 		vector<MyTuple> stack;
	// 		RecvData(&stack,0);
	// 		sort(stack.begin(), stack.end());
	// 		SendData(&stack,0);
	// 	}
	// }
	// if(world_rank == 0)
	// {
	// 	// Receive data
	// 	for (int i = 1; i < world_size; ++i)
	// 	{
	// 		for (int j = 0; j < chunkSize; ++j)
	// 		{
	// 			if((i-1)*chunkSize+j >= cols)
	// 				break;
	// 			vector<MyTuple> stack;
	// 			RecvData(&stack,i);
	// 			// input[(i-1)*chunkSize+j] = stack;
	// 		}
	// 	}
	// }

	// Writing output to file
	if (world_rank == 0)
	{
		sort(input.begin(), input.end(), row_major);
		printfile(argv[2]);
	}
	MPI_Finalize();
	return 0;
}