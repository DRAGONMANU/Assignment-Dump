/*
 * $HEADER$
 */
#if defined(c_plusplus) || defined(__cplusplus)
extern "C" {
#endif



const ompi_mpiext_component_t *ompi_mpiext_components[] = {

  NULL
};

#if defined(c_plusplus) || defined(__cplusplus)
}
#endif

