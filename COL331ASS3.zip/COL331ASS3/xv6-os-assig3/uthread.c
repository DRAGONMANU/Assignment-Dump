#include "types.h"
#include "stat.h"
#include "user.h"

/* Possible states of a thread; */
#define FREE        0x0
#define RUNNING     0x1
#define RUNNABLE    0x2
#define WAITING     0x3

#define STACK_SIZE  8192
#define MAX_THREAD  6

int AGING = 0;
int DONATION = 0;
typedef struct thread thread_t, *thread_p;
typedef struct mutex mutex_t, *mutex_p;

struct thread {
  int        sp;                /* curent stack pointer */
  char stack[STACK_SIZE];       /* the thread's stack */
  int        state;             /* running, runnable, waiting */
  char* name;
  int priority;
  int age;
  int init_priority;
};

struct mutex
{
  int locked;
  char* locker_name;
};

mutex_p lock;


static thread_t all_thread[MAX_THREAD];
thread_p  current_thread;
thread_p  next_thread;
extern void thread_switch(void);

void 
thread_init(void)
{
  current_thread = &all_thread[0];
  current_thread->state = RUNNING;
  lock->locked = 0;
}

static void 
thread_schedule(void)
{
  int highest = 0;
  thread_p temp = 0;

  thread_p t;

	if (AGING==1)
	{
	  for (t = all_thread; t < all_thread + MAX_THREAD; t++)
	  	if (t->state == RUNNABLE)
	  	{
		  	t->age++;
		  	if (t->age==5)
		  	{
		  		t->age = 0;
		  		if (t->priority < 5)
			  		t->priority++;
		  	}
		  }
	}

  /* Find another runnable thread. */
  for (t = current_thread; t < all_thread + MAX_THREAD; t++) {
    if (t->state == RUNNABLE && t != current_thread && t->priority >= highest) {
      temp = t;
      highest = t->priority;
    }
  }
  for (t = all_thread; t < current_thread; t++) {
    if (t->state == RUNNABLE && t != current_thread && t->priority >= highest) {
      temp = t;
      highest = t->priority;
    }
  }

  next_thread = temp;

  if (highest < current_thread->priority && current_thread->state == RUNNABLE) {
    /* The current thread is the only runnable thread; run it. */
    next_thread = current_thread;
  }

  if (next_thread == 0) {
    printf(2, "thread_schedule: no runnable threads; possible deadlock\n");
    exit();
  }

  if (current_thread != next_thread) {         /* switch threads?  */
    next_thread->state = RUNNING;
    thread_switch();
  } else
    next_thread = 0;
}

int 
thread_create(const char *name, void (*func)(), int priority)
{
  thread_p t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    if (t->state == FREE) break;
  }
  t->sp = (int) (t->stack + STACK_SIZE);   // set sp to the top of the stack
  t->sp -= 4;                              // space for return address
  * (int *) (t->sp) = (int)func;           // push return address on stack
  t->sp -= 32;                             // space for registers that thread_switch will push
  t->state = RUNNABLE;
  int size = 0;
  for (int i = 0; name[i] != '\0'; ++i)
  {
    size++;
  }
  t->name = malloc (size+1);
  for (int j = 0; j<size; ++j)
  {
    t->name[j]=name[j];
  }
  t->name[size]='\0';
  t->priority = priority;
  t->init_priority = priority;
  t->age = 0;
  return 1;
}

void 
thread_yield(void)
{
  current_thread->state = RUNNABLE;
  thread_schedule();
}

void lock_busy_wait_acquire()
{
  char* name = current_thread->name;
  while(lock->locked==1)
  {
  	if(DONATION==0)
  	{
	    printf(1, "failed by %s\n", current_thread->name);
	    thread_yield();
	  }
	  else
	  {
	  	thread_p t;
		  for (t = all_thread; t < all_thread + MAX_THREAD; t++) 
		  {
		  	if(!strcmp(t->name,lock->locker_name) && t->priority < current_thread->priority)
	  		{
	    		printf(1, "locker by %s\n", t->name);
	  			t->priority = current_thread->priority;
		  		break;
	  		}
	  	}
	    printf(1, "donated by %s\n", current_thread->name);
	    thread_yield();
		}
	}
  int size = 0;
  for (int i = 0; name[i] != '\0'; ++i)
    size++;
  lock->locker_name = malloc (size+1);
  for (int j = 0; j<size; ++j)
    lock->locker_name[j]=name[j];
  lock->locked = 1;
  printf(1, "locked by %s\n", current_thread->name);  
}


void lock_busy_wait_release()
{
  char* name = current_thread->name;
  int size = 0;
  int eq = 0;
  for (int i = 0; name[i] != '\0'; ++i)
  {
    size++;
  }
  for (int j = 0; j<size; ++j)
  {
    if(lock->locker_name[j]!=name[j])
      eq = 1;
  }

  if(lock->locked==1 && eq==0)
  {
    lock->locked = 0;
    current_thread->priority = current_thread->init_priority;
    printf(1, "released by %s\n", current_thread->name);
  }
}


void lock_acquire()
{
  if(lock->locked==1)
  {
    current_thread->state = WAITING;
    printf(1, "failed by %s\n", current_thread->name);
    thread_schedule();
  }
  else
  {
   lock->locked=1; 
    printf(1, "locked by %s\n", current_thread->name);  
  }
}

void lock_release()
{
  if (lock->locked==1)
  {
    int avai = 0;
    thread_p t;
    for (t = all_thread; t < all_thread + MAX_THREAD; t++) 
    {
      if (t->state == WAITING)
      {  
        t->state = RUNNABLE;
        printf(1, "saved %s by %s\n", t->name ,current_thread->name);
        lock->locked = 1;
        avai = 1;
        break;
      }
    }
    printf(1, "released by %s\n", current_thread->name);
    if (avai==0)
      lock->locked = 0;
  }
}



static void 
mythread0(void)
{
  int i;
  printf(1, "my thread running\n");
  for (i = 0; i < 10; i++) {
    printf(1, "%s %d\n", current_thread->name,i);
    thread_yield();
  }
  printf(1, "my thread: exit\n");
  current_thread->state = FREE;
  thread_schedule();
}

void sample0() 
{
	AGING = 1;
  thread_init();
  char *a = "a";
  char *b = "b";
  thread_create(a,mythread0,4);
  thread_create(b,mythread0,5);
  thread_schedule();
}

static void 
mythread1(void)
{
  int i;
  printf(1, "my thread running\n");
  lock_busy_wait_acquire();
  for (i = 0; i < 10; i++) {
    printf(1, "%s %d\n", current_thread->name,i);
    thread_yield();
  }
  lock_busy_wait_release();
  printf(1, "my thread: exit\n");
  current_thread->state = FREE;
  thread_schedule();
}

void sample1() 
{
  thread_init();
  char *a = "a";
  char *b = "b";
  char *c = "c";
  char *d = "d";
  char *e = "e";

  thread_create(a,mythread1,5);
  thread_create(b,mythread1,1);
  thread_create(c,mythread1,4);
  thread_create(d,mythread1,4);
  thread_create(e,mythread1,1);

  thread_schedule();
}

static void 
mythread2(void)
{
  int i;
  printf(1, "my thread running\n");
  lock_acquire();
  for (i = 0; i < 10; i++) {
    printf(1, "%s %d\n", current_thread->name,i);
    thread_yield();
  }
  lock_release();
  printf(1, "my thread: exit\n");
  current_thread->state = FREE;
  thread_schedule();
}

void sample2() 
{
  thread_init();
  char *a = "a";
  char *b = "b";
  char *c = "c";
  char *d = "d";
  thread_create(a,mythread2,2);
  thread_create(b,mythread2,2);
  thread_create(c,mythread2,2);
  thread_create(d,mythread2,2);
  thread_schedule();
}

static void 
mythread3(void)
{
  int i;
  printf(1, "my thread running\n");
  lock_busy_wait_acquire();
  char *b = "b";
	thread_create(b,mythread1,2);
  for (i = 0; i < 10; i++) {
    printf(1, "%s %d\n", current_thread->name,i);
    thread_yield();
  }
  lock_busy_wait_release();
  printf(1, "my thread: exit\n");
  current_thread->state = FREE;
  thread_schedule();
}

void sample3() 
{
  thread_init();
  char *a = "a";
  thread_create(a,mythread3,1);
  thread_schedule();
}



void sample4() 
{
	DONATION = 1;
  sample3();
}

int main(int argc, char *argv[]) 
{
  // sample0(); //aging with priority scheduling 
  // sample1(); //busy wait with priority scheduling
  // sample2(); //no busy wait with priority scheduling
  // sample3(); //priority inversion
  sample4(); //priority donation

  return 0;
}
