#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string>
#include <string.h>
#include <stdlib.h>
#include <vector>
#include <algorithm>
#include <mpi.h>

using namespace std;

typedef struct MyTuple
{
	float key;
	string value;
	bool operator < (const MyTuple& str) const
    {
        return (key < str.key);
    }
}MyTuple ;


vector<vector<MyTuple> > input;

bool less_size(const vector<MyTuple>& a,const vector<MyTuple>& b)
{
   return a.size() > b.size();
}

void readfile(int procid, string base, int cols)
{
	int chunkSize = cols;
	char *buf;
	for (int i = procid*chunkSize; i < (procid+1)*chunkSize; ++i)
	{
		string fileName, fileId;
		char buffer[20]; // Max num of digits for 64 bit number
    	sprintf(buffer,"%d", i+1);
		fileName = base + string(buffer);
		ifstream inputFile(fileName, ios::in | ios::binary);
		if (!inputFile)
		{
			cout << "can't open file" << endl;
			exit(1);
		}
		int intBuffer;
		inputFile.read(reinterpret_cast<char *>(&intBuffer), sizeof(int));
		float floatBuffer;
		vector<MyTuple> temp;
		while(inputFile.read(reinterpret_cast<char *>(&floatBuffer), sizeof(float)))
	   	{
	   		buf = new char[intBuffer];
			inputFile.read(buf, intBuffer);
			string charBuffer = "";
			charBuffer.append(buf, intBuffer);
			MyTuple t;
	   		t.key = floatBuffer;
	   		t.value = charBuffer;
	   		temp.push_back(t);
	   	}
	   	input.push_back(temp);
	   	inputFile.close();
	}
	free(buf);
}

void printfile(int procid, string base, int cols)
{

	string fileName = base + "0";
	ofstream output (fileName, ios::out | ios::binary);
	if (!output)
	{
		cout << "can't open file" << endl;
		exit(1);
	}
	for (int i = 0; i < input[0].size(); ++i)
	{
		for (int j = 0; j < input.size(); ++j)
		{
			if(i >= input[j].size())
				break;
			float key = input[j][i].key;
			int len = input[j][i].value.size();
			string value = input[j][i].value;
			output.write(reinterpret_cast<char *>(&key), sizeof(float));
			output.write(value.c_str(), len);
		}
	}
	output.flush();
	output.close();
}

void SendData(vector<MyTuple>* shoot,int dest)
{
	MPI_Send((void*)shoot->data(),shoot->size() * sizeof(MyTuple), MPI_BYTE, dest, 0, MPI_COMM_WORLD);
}

void RecvData(vector<MyTuple>* shoot,int dest)
{
	MPI_Status status;
	int incoming_size;
	MPI_Probe(dest, 0, MPI_COMM_WORLD, &status);
  	MPI_Get_count(&status, MPI_BYTE, &incoming_size);
  	shoot->resize(incoming_size / sizeof(MyTuple));
	// MPI_Recv((void*)shoot->data(),incoming_size, MPI_BYTE, dest, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
}

int main(int argc, char const *argv[])
{
	if (argc!=3)
	{
		printf("wrong arguements\n");
		exit(1);
	}
	MPI_Init(NULL, NULL);
	int world_rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
	int world_size;
	MPI_Comm_size(MPI_COMM_WORLD, &world_size);
	int number;

	int debug = 0;
	int id = 0;
	int cols = atoi(argv[1]);
	string base = string(argv[2]);
	int chunkSize = cols/(world_size-1);
	if(chunkSize < 1)
		chunkSize = 1;
	if (world_rank == 0)
	{
		readfile(id,base,cols);

		// Sort according to length - DONE
		sort(input.begin(), input.end(), less_size);

		// Sort according to rows - DONE
		for (int i = 0; i < input[0].size(); ++i)
		{
			vector<MyTuple> temp;
			for (int j = 0; j < input.size(); ++j)
			{
				if(i >= input[j].size())
					break;
				temp.push_back(input[j][i]);
			}
			int k = temp.size();
			sort(temp.begin(), temp.end());

			for (int j = 0; j < input.size(); ++j)
			{
				if(i >= input[j].size())
					break;
				input[j][i] = temp[j];
			}
		}
	}

	// Sort according to col
	if(world_rank == 0)
	{
		// Send data acc to chunks to each proc
		for (int i = 1; i < world_size; ++i)
		{
			for (int j = 0; j < chunkSize; ++j)
			{
				if((i-1)*chunkSize+j >= cols)
					break;
				SendData(&input[(i-1)*chunkSize+j],i);
			}
		}
	}
	else
	{
		for (int i = 0; i < chunkSize; ++i)
		{
			vector<MyTuple> stack;
			RecvData(&stack,0);
			sort(stack.begin(), stack.end());
			SendData(&stack,0);
		}
	}
	if(world_rank == 0)
	{
		// Receive data
		for (int i = 1; i < world_size; ++i)
		{
			for (int j = 0; j < chunkSize; ++j)
			{
				if((i-1)*chunkSize+j >= cols)
					break;
				vector<MyTuple> stack;
				RecvData(&stack,i);
				// input[(i-1)*chunkSize+j] = stack;
			}
		}
	}

	// Writing output to file
	if (world_rank == 0)
	{
		for (int i = 0; i < input.size(); ++i)
			sort(input[i].begin(), input[i].end());

		printfile(id,base,cols);
	}
	MPI_Finalize();
	return 0;
}