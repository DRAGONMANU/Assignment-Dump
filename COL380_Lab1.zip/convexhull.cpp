#include "iostream"
#include "vector"
#include "ctime"
#include "omp.h"
#include <string>
#include <fstream>
#include <set>
#include <math.h>

using namespace std;

set<pair<int, int> > convexHull;

int findSide(pair<int, int> p, pair<int, int> a, pair<int, int> b)
{
	int check = (p.second - a.second) * (b.first - a.first) - (b.second - a.second) * (p.first - a.first);
	return check;// > 0 ? 1 : (check == 0 ? 0 : -1);
}

int findSide1(pair<int, int> p, pair<int, int> a, pair<int, int> b)
{
	int check = (p.second - a.second) * (b.first - a.first) - (b.second - a.second) * (p.first - a.first);
	return check > 0 ? 1 : (check == 0 ? 0 : -1);
}



void quickhull(vector<pair<int, int> > group, pair<int, int> a, pair<int, int> b, int side, int num_threads)
{
	int j = -1;
	float max = 0;
	float temp = 0.0;
#pragma omp parallel for num_threads(num_threads) schedule(static)
	for (int i = 0; i < group.size(); i++)
	{
#pragma omp critical
		{
			temp = fabs(findSide(group[i], a, b));
			if (side == findSide1(group[i], a, b) && temp >= max)
			{
				max = temp;
				j = i;
			}
		}
	}
#pragma omp barrier
	if (j < 0)
	{
		convexHull.insert(a);
		convexHull.insert(b);
		return;
	}
	quickhull(group, group[j], a, -1 * findSide1(b, group[j], a), num_threads);
	quickhull(group, group[j], b, -1 * findSide1(a, group[j], b), num_threads);
}

vector<pair<int, int> > calcConvexHull(vector<vector<int> > image, int num_threads)
{
	num_threads = 1;
	omp_set_num_threads(num_threads);
	vector<pair<int, int> > points;
	int m = image.size();
	int n = image[0].size();
	for (int i = 0; i < n; i++)
	{
// #pragma omp parallel for num_threads(num_threads) schedule(static)
		for (int j = 0; j < m; j++)
		{
	// #pragma omp critical
			{
				if (image[j][i] == 1)
				{
					points.push_back(make_pair(j, i));
				}
			}
		}
	}
	for(int i = 0;i<points.size();i++)
	{
		cout<<points[i].first<<" "<<points[i].second<<endl;
	}

// #pragma omp barrier
	quickhull(points, points[0], points[points.size() - 1], 1, num_threads);
	quickhull(points, points[0], points[points.size() - 1], -1, num_threads);
	vector<pair<int, int> > cx(convexHull.begin(), convexHull.end());
	return cx;
}