#include "iostream"
#include "vector"
#include "ctime"
#include "omp.h"
#include <math.h>

vector<int> calcPrefixSum(vector<int> input, int num_threads)
{
	omp_set_num_threads(num_threads);

	int n = input.size();
	for (int i = 0; i < ceil(log2(n)); i++)
	{
		int step = pow(2, i+1);
#pragma omp parallel for num_threads(num_threads) schedule(static)
		for (int j = step-1; j < n; j+=step)
		{
			input[j] += input[j - step / 2];
		}
	}
	for (int i = ceil(log2(n))-1; i > 0; i--)
	{
		int step = pow(2, i);
#pragma omp parallel for num_threads(num_threads) schedule(static)
		for (int j = step - 1; j < n-step/2; j += step)
		{
			input[j+step/2] += input[j];
		}
	}
	return input;
}